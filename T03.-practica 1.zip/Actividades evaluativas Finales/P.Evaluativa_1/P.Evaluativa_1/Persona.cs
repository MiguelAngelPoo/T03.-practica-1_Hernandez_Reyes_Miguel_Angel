﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P.Evaluativa_1
{
    public class Persona
    {
        //encapsulacion de los valores
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Profesion { get; set; }
        public int Edad { get; set; }
    }
}
